Favourite Gibberish

Chaotiably: Adverb. To do something in a chaotic, yet cautious fashion; Chaotic good.

Toboggings: Plural noun; A mix between a toboggan and leggings; leggings that cover both legs, historically hard to walk in.

Foreterminating: Verb; Finishing something before its even begun.

Lamethropisms: Plural adjective; Multiple failed attempts at philanthropism, usually because of a excessively obvious secondary motives.

Unafrases: Noun; A primitive form of Newspeak where long phrases are shortened to change their meaning.

Unbrides: Noun; Brides who were told they were no longer to marry their counterpart at the altar.

Noseburglarize: Verb; To pretend to rob someone's nose, usually a much younger someone.

Faerobiolograms: Plural noun; I don't know, it just sounds really cool and I don't have anything as a definition for this.

Compathy: Noun; Short for empathy towards companies (or apathy, use is varied and directly dependent on one's political views).